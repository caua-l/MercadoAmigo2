const products = [
    {
        "id": 1,
        "name": "PACOTE DE BATATAS",
        "price": 5.99,
        "description":"Batata Pré-Frita Mais Batata Congelada 2kg",
        "image":"imagens/batatas reais.jpg"
    },
     {
        "id": 2,
        "name": "CAIXA DE LEITE",
        "price": 8.99,
        "description":"Leite integral 1 litro ITALAC",
        "image":"imagens/LEITE.JPG"
    }
];
export default products;